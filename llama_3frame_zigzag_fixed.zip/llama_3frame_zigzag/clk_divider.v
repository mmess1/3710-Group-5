module clk_divider
(
    input  wire clk,
    input  wire rst,
    output reg  div_clk
);

always @(posedge clk or negedge rst) begin
    if (~rst)
        div_clk <= 1'b0;
    else
        div_clk <= ~div_clk;
end

endmodule
