/**
  * piskel_to_hex.c
  *
  * Converts exported Piskel C-array data into a hex file that can be loaded
  * into ROM for VGA glyph reading in Verilog.
  *
  * Output is formatted pixel by pixel. Each line in the outputted hex file is
  * a single RGB pixel in RRGGBB format.
  *
  * Pre-requisites:
  *   (1) adjust outputted piskel C file to header file: <filename>.h
  *   (2) remove the static keyword from the data array
  *   (3) rename the array to just be data
  *   (4) rename the frame-count macro to FRAME_COUNT
  *   (5) rename width/height macros to FRAME_WIDTH and FRAME_HEIGHT
  */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "mario.h"

#define FILENAME "glyphs.hex"

static uint8_t get_red(uint32_t pixel)
{
    return (uint8_t)(pixel >> 0);
}

static uint8_t get_green(uint32_t pixel)
{
    return (uint8_t)(pixel >> 8);
}

static uint8_t get_blue(uint32_t pixel)
{
    return (uint8_t)(pixel >> 16);
}

int main(void)
{
    FILE *fptr;
    time_t now;
    int i, j;
    uint8_t r, g, b;

    time(&now);

    /* overwrite the previous hex file each time */
    fptr = fopen(FILENAME, "w");
    if (fptr == NULL) {
        printf("\r\nERROR opening %s\r\n\r\n", FILENAME);
        exit(1);
    }

    printf("\r\nIterating sprites...");

    fprintf(fptr, "// Outputted data from piskel_to_hex.c\r\n");
    fprintf(fptr, "// Glyph width: %u\r\n", FRAME_WIDTH);
    fprintf(fptr, "// Glyph height: %u\r\n", FRAME_HEIGHT);

    for (i = 0; i < FRAME_COUNT; i++) {
        fprintf(fptr, "\n\n// glyph[%u] -- added %s\r\n\n", i, ctime(&now));
        for (j = 0; j < (FRAME_WIDTH * FRAME_HEIGHT); j++) {
            r = get_red(data[i][j]);
            g = get_green(data[i][j]);
            b = get_blue(data[i][j]);
            fprintf(fptr, "%02x%02x%02x\r\n", r, g, b);
        }
    }

    printf("Done!\r\n\r\n");
    fclose(fptr);
    return 0;
}
