module glyph_addr_gen
#(
    parameter GLYPH_DATA_WIDTH   = 24,
    parameter SYS_DATA_WIDTH     = 18,
    parameter SYS_ADDR_WIDTH     = 16,
    parameter GLYPH_ADDR_WIDTH   = 16,
    parameter LOG2_DISPLAY_WIDTH = 10,
    parameter LOG2_DISPLAY_HEIGHT= 10
)
(
    input  wire                                 clk,
    input  wire                                 rst,
    input  wire                                 vga_blank_n,
    input  wire                                 vga_vs,
    input  wire                                 vga_hs,
    input  wire [9:0]                           hcount,
    input  wire [9:0]                           vcount,
    input  wire [(SYS_DATA_WIDTH-1):0]          sys_data,
    output reg  [(GLYPH_ADDR_WIDTH-1):0]        glyph_addr,
    output reg  [(SYS_ADDR_WIDTH-1):0]          sys_addr,
    output reg  [23:0]                          bg_color,
    output reg                                  pix_en
);

localparam BG_COLOR           = 24'hFFFFFF;
localparam FETCH0             = 8'h00;
localparam FETCH1             = 8'h01;
localparam FETCH2             = 8'h02;
localparam FETCH3             = 8'h03;
localparam FETCH_PIXEL        = 8'hFF;
localparam LLAMA_GLYPH_WIDTH  = 48;
localparam LLAMA_GLYPH_HEIGHT = 48;
localparam LLAMA_GLYPH_SIZE   = 2304; // 48 * 48

reg [7:0] PS, NS;

wire [(LOG2_DISPLAY_WIDTH-1):0]  x_pos;
wire [(LOG2_DISPLAY_HEIGHT-1):0] y_pos;
assign x_pos = hcount;
assign y_pos = vcount;

reg  llama_x_en, llama_y_en, llama_m_en;
wire [(SYS_DATA_WIDTH-1):0] llama_x_pos, llama_y_pos, llama_m_pos;

register #(SYS_DATA_WIDTH) llama_x_reg (.clk(clk), .rst(rst), .en(llama_x_en), .d(sys_data), .q(llama_x_pos));
register #(SYS_DATA_WIDTH) llama_y_reg (.clk(clk), .rst(rst), .en(llama_y_en), .d(sys_data), .q(llama_y_pos));
register #(SYS_DATA_WIDTH) llama_m_reg (.clk(clk), .rst(rst), .en(llama_m_en), .d(sys_data), .q(llama_m_pos));

wire [(LOG2_DISPLAY_WIDTH-1):0]  llama_x_off;
wire [(LOG2_DISPLAY_HEIGHT-1):0] llama_y_off;
assign llama_x_off = x_pos - llama_x_pos;
assign llama_y_off = y_pos - llama_y_pos;

always @(posedge clk or negedge rst) begin
    if (~rst)
        PS <= FETCH0;
    else if (~vga_vs)
        PS <= FETCH0;
    else
        PS <= NS;
end

always @* begin
    sys_addr   = {SYS_ADDR_WIDTH{1'b0}};
    glyph_addr = {GLYPH_ADDR_WIDTH{1'b0}};
    llama_x_en = 1'b0;
    llama_y_en = 1'b0;
    llama_m_en = 1'b0;
    pix_en     = 1'b0;
    bg_color   = BG_COLOR;
    NS         = PS;

    case (PS)
        FETCH0: begin
            sys_addr = 16'h1000;
            NS = FETCH1;
        end

        FETCH1: begin
            llama_x_en = 1'b1;
            sys_addr   = 16'h1001;
            NS         = FETCH2;
        end

        FETCH2: begin
            llama_y_en = 1'b1;
            sys_addr   = 16'h1002;
            NS         = FETCH3;
        end

        FETCH3: begin
            llama_m_en = 1'b1;
            NS         = FETCH_PIXEL;
        end

        FETCH_PIXEL: begin
            if (vga_blank_n &&
                (x_pos >= llama_x_pos) &&
                (x_pos < (llama_x_pos + LLAMA_GLYPH_WIDTH)) &&
                (y_pos >= llama_y_pos) &&
                (y_pos < (llama_y_pos + LLAMA_GLYPH_HEIGHT))) begin
                glyph_addr = (llama_m_pos * LLAMA_GLYPH_SIZE) +
                             (llama_y_off * LLAMA_GLYPH_WIDTH) +
                              llama_x_off;
                pix_en = 1'b1;
            end
            NS = FETCH_PIXEL;
        end

        default: begin
            NS = FETCH0;
        end
    endcase
end

endmodule
