module bram
#(
    parameter DATA_WIDTH = 16,
    parameter ADDR_WIDTH = 16
)
(
    input  wire                   clk,
    input  wire                   we_a,
    input  wire                   we_b,
    input  wire [(DATA_WIDTH-1):0] data_a,
    input  wire [(DATA_WIDTH-1):0] data_b,
    input  wire [(ADDR_WIDTH-1):0] addr_a,
    input  wire [(ADDR_WIDTH-1):0] addr_b,
    output reg  [(DATA_WIDTH-1):0] q_a,
    output reg  [(DATA_WIDTH-1):0] q_b
);

reg [DATA_WIDTH-1:0] ram [0:(2**ADDR_WIDTH)-1];

initial begin
    // Sprite state memory
    ram[16'h1000] = 16'd40; // x position
    ram[16'h1001] = 16'd40; // y position
    ram[16'h1002] = 16'd0;  // animation frame: only 0,1,2 are used
end

always @(posedge clk) begin
    if (we_a) begin
        ram[addr_a] <= data_a;
        q_a <= data_a;
    end
    else begin
        q_a <= ram[addr_a];
    end
end

always @(posedge clk) begin
    if (we_b) begin
        ram[addr_b] <= data_b;
        q_b <= data_b;
    end
    else begin
        q_b <= ram[addr_b];
    end
end

endmodule
