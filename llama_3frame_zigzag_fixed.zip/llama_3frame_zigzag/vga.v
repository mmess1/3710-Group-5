module vga
#(
    parameter SYS_DATA_WIDTH   = 16,
    parameter SYS_ADDR_WIDTH   = 16,
    parameter GLYPH_DATA_WIDTH = 24,
    parameter GLYPH_ADDR_WIDTH = 14
)
(
    input  wire [(SYS_DATA_WIDTH-1):0] sys_data,
    input  wire                        clk,
    input  wire                        rst,
    output wire                        vga_clk,
    output wire                        vga_blank_n,
    output wire                        vga_vs,
    output wire                        vga_hs,
    output wire [7:0]                  r,
    output wire [7:0]                  g,
    output wire [7:0]                  b,
    output wire [(SYS_ADDR_WIDTH-1):0] sys_addr
);

localparam LOG2_DISPLAY_WIDTH  = 10;
localparam LOG2_DISPLAY_HEIGHT = 10;

wire [(LOG2_DISPLAY_WIDTH-1):0]  hcount;
wire [(LOG2_DISPLAY_HEIGHT-1):0] vcount;
wire [(GLYPH_ADDR_WIDTH-1):0]    glyph_addr;
wire [(GLYPH_DATA_WIDTH-1):0]    pixel;
wire [23:0]                      bg_color;
wire                             pix_en;
reg                              pix_en_out;

clk_divider clk_div (
    .clk(clk),
    .rst(rst),
    .div_clk(vga_clk)
);

vga_controller ctrl (
    .vga_clk(vga_clk),
    .rst(rst),
    .vga_hs(vga_hs),
    .vga_vs(vga_vs),
    .vga_blank_n(vga_blank_n),
    .hcount(hcount),
    .vcount(vcount)
);

always @(posedge vga_clk or negedge rst) begin
    if (~rst)
        pix_en_out <= 1'b0;
    else
        pix_en_out <= pix_en;
end

bitgen #(.DATA_WIDTH(GLYPH_DATA_WIDTH)) bitgen_i (
    .vga_blank_n(vga_blank_n),
    .pix_en(pix_en_out),
    .pixel(pixel),
    .bg_color(bg_color),
    .rgb({r,g,b})
);

glyph_addr_gen #(
    .GLYPH_DATA_WIDTH(GLYPH_DATA_WIDTH),
    .SYS_DATA_WIDTH(SYS_DATA_WIDTH),
    .SYS_ADDR_WIDTH(SYS_ADDR_WIDTH),
    .GLYPH_ADDR_WIDTH(GLYPH_ADDR_WIDTH),
    .LOG2_DISPLAY_WIDTH(LOG2_DISPLAY_WIDTH),
    .LOG2_DISPLAY_HEIGHT(LOG2_DISPLAY_HEIGHT)
) addr_gen (
    .clk(vga_clk),
    .rst(rst),
    .vga_blank_n(vga_blank_n),
    .vga_vs(vga_vs),
    .vga_hs(vga_hs),
    .hcount(hcount),
    .vcount(vcount),
    .sys_data(sys_data),
    .glyph_addr(glyph_addr),
    .sys_addr(sys_addr),
    .bg_color(bg_color),
    .pix_en(pix_en)
);

glyph_rom #(
    .DATA_WIDTH(GLYPH_DATA_WIDTH),
    .ADDR_WIDTH(GLYPH_ADDR_WIDTH)
) glyphs (
    .clk(vga_clk),
    .addr(glyph_addr),
    .q(pixel)
);

endmodule
