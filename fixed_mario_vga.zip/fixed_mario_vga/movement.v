module movement
#(
    parameter DATA_WIDTH = 16,
    parameter ADDR_WIDTH = 16
)
(
    input  wire                        clk,
    input  wire                        rst,
    input  wire [(DATA_WIDTH-1):0]     data_in,
    output reg  [(ADDR_WIDTH-1):0]     addr,
    output reg  [(DATA_WIDTH-1):0]     data_out,
    output reg                         we
);

// At 25 MHz, 1_250_000 cycles is about 50 ms between movement updates.
localparam COUNT      = 32'd1250000;
localparam STATE_ITER = 32'd3;
wire timer;

pulse pwm (
    .clk(clk),
    .rst(rst),
    .length1(STATE_ITER),
    .length2(COUNT),
    .pulse(timer)
);

localparam FETCH_X          = 3'd0;
localparam SAVE_X           = 3'd1;
localparam FETCH_M          = 3'd2;
localparam SAVE_M           = 3'd3;
localparam SAVE_M_STANDING  = 3'd4;
localparam IDLE             = 3'd5;

reg [2:0] PS, NS;

localparam MARIO_X_END      = 16'd300;
localparam MARIO_STEP       = 16'd4;
localparam MARIO_STANDING   = 16'd0;
localparam MARIO_WALK_START = 16'd1;
localparam MARIO_WALK_MID   = 16'd2;
localparam MARIO_WALK_END   = 16'd3;

reg inc_in, inc_out;

always @(posedge clk or negedge rst) begin
    if (~rst)
        inc_out <= 1'b1;
    else
        inc_out <= inc_in;
end

always @(posedge clk or negedge rst) begin
    if (~rst)
        PS <= FETCH_X;
    else if (timer)
        PS <= NS;
end

always @* begin
    addr     = {ADDR_WIDTH{1'b0}};
    data_out = {DATA_WIDTH{1'b0}};
    we       = 1'b0;
    inc_in   = inc_out;
    NS       = PS;

    case (PS)
        FETCH_X: begin
            addr = 'h1000;
            NS = SAVE_X;
        end

        SAVE_X: begin
            addr = 'h1000;
            if (data_in < MARIO_X_END) begin
                data_out = data_in + MARIO_STEP;
                we = 1'b1;
                NS = FETCH_M;
            end
            else begin
                NS = SAVE_M_STANDING;
            end
        end

        FETCH_M: begin
            addr = 'h1002;
            NS = SAVE_M;
        end

        SAVE_M: begin
            addr = 'h1002;
            we = 1'b1;
            case (data_in)
                MARIO_STANDING: begin
                    data_out = MARIO_WALK_START;
                    inc_in = 1'b1;
                end

                MARIO_WALK_START: begin
                    data_out = MARIO_WALK_MID;
                    inc_in = 1'b1;
                end

                MARIO_WALK_MID: begin
                    if (inc_out)
                        data_out = MARIO_WALK_START;
                    else
                        data_out = MARIO_WALK_END;
                    inc_in = inc_out;
                end

                MARIO_WALK_END: begin
                    data_out = MARIO_WALK_MID;
                    inc_in = 1'b0;
                end

                default: begin
                    data_out = MARIO_STANDING;
                    inc_in = 1'b1;
                end
            endcase
            NS = FETCH_X;
        end

        SAVE_M_STANDING: begin
            addr = 'h1002;
            data_out = MARIO_STANDING;
            we = 1'b1;
            NS = IDLE;
        end

        IDLE: begin
            NS = IDLE;
        end

        default: begin
            NS = FETCH_X;
        end
    endcase
end

endmodule
