module glyph_addr_gen
#(
    parameter GLYPH_DATA_WIDTH    = 24,
    parameter SYS_DATA_WIDTH      = 18,
    parameter SYS_ADDR_WIDTH      = 16,
    parameter GLYPH_ADDR_WIDTH    = 16,
    parameter LOG2_DISPLAY_WIDTH  = 10,
    parameter LOG2_DISPLAY_HEIGHT = 10
)
(
    input  wire                            clk,
    input  wire                            rst,
    input  wire                            vga_blank_n,
    input  wire                            vga_vs,
    input  wire                            vga_hs,
    input  wire [9:0]                      hcount,
    input  wire [9:0]                      vcount,
    input  wire [(SYS_DATA_WIDTH-1):0]     sys_data,
    output reg  [(GLYPH_ADDR_WIDTH-1):0]   glyph_addr,
    output reg  [(SYS_ADDR_WIDTH-1):0]     sys_addr,
    output reg  [23:0]                     bg_color,
    output reg                             pix_en
);

localparam BG_COLOR           = 24'hFFFFFF;
localparam FETCH0             = 8'h00;
localparam FETCH1             = 8'h01;
localparam FETCH2             = 8'h02;
localparam FETCH3             = 8'h03;
localparam FETCH_PIXEL        = 8'hFF;

// Match the supplied glyphs.hex comments: 48x48 frames.
localparam GLYPH_WIDTH        = 48;
localparam GLYPH_HEIGHT       = 48;
localparam GLYPH_SIZE         = 2304; // 48 * 48

reg [7:0] PS, NS;

wire [(LOG2_DISPLAY_WIDTH-1):0]  x_pos;
wire [(LOG2_DISPLAY_HEIGHT-1):0] y_pos;
assign x_pos = hcount;
assign y_pos = vcount;

reg  sprite_x_en, sprite_y_en, sprite_f_en;
wire [(SYS_DATA_WIDTH-1):0] sprite_x_pos, sprite_y_pos, sprite_f_pos;

register #(SYS_DATA_WIDTH) sprite_x_reg (.clk(clk), .rst(rst), .en(sprite_x_en), .d(sys_data), .q(sprite_x_pos));
register #(SYS_DATA_WIDTH) sprite_y_reg (.clk(clk), .rst(rst), .en(sprite_y_en), .d(sys_data), .q(sprite_y_pos));
register #(SYS_DATA_WIDTH) sprite_f_reg (.clk(clk), .rst(rst), .en(sprite_f_en), .d(sys_data), .q(sprite_f_pos));

wire [(LOG2_DISPLAY_WIDTH-1):0]  sprite_x_off;
wire [(LOG2_DISPLAY_HEIGHT-1):0] sprite_y_off;
assign sprite_x_off = x_pos - sprite_x_pos;
assign sprite_y_off = y_pos - sprite_y_pos;

always @(posedge clk or negedge rst) begin
    if (~rst)
        PS <= FETCH0;
    else if (~vga_vs)
        PS <= FETCH0;
    else
        PS <= NS;
end

always @* begin
    sys_addr   = {SYS_ADDR_WIDTH{1'b0}};
    glyph_addr = {GLYPH_ADDR_WIDTH{1'b0}};
    sprite_x_en = 1'b0;
    sprite_y_en = 1'b0;
    sprite_f_en = 1'b0;
    pix_en     = 1'b0;
    bg_color   = BG_COLOR;
    NS         = PS;

    case (PS)
        FETCH0: begin
            sys_addr = 16'h1000;
            NS = FETCH1;
        end

        FETCH1: begin
            sprite_x_en = 1'b1;
            sys_addr    = 16'h1001;
            NS          = FETCH2;
        end

        FETCH2: begin
            sprite_y_en = 1'b1;
            sys_addr    = 16'h1002;
            NS          = FETCH3;
        end

        FETCH3: begin
            sprite_f_en = 1'b1;
            NS          = FETCH_PIXEL;
        end

        FETCH_PIXEL: begin
            if (vga_blank_n &&
                (x_pos >= sprite_x_pos) &&
                (x_pos < (sprite_x_pos + GLYPH_WIDTH)) &&
                (y_pos >= sprite_y_pos) &&
                (y_pos < (sprite_y_pos + GLYPH_HEIGHT))) begin
                glyph_addr = (sprite_f_pos * GLYPH_SIZE) +
                             (sprite_y_off * GLYPH_WIDTH) +
                              sprite_x_off;
                pix_en = 1'b1;
            end
            NS = FETCH_PIXEL;
        end

        default: begin
            NS = FETCH0;
        end
    endcase
end

endmodule
