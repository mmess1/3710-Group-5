module movement
#(
    parameter DATA_WIDTH = 16,
    parameter ADDR_WIDTH = 16
)
(
    input  wire                    clk,
    input  wire                    rst,
    input  wire [(DATA_WIDTH-1):0] data_in,
    output reg  [(ADDR_WIDTH-1):0] addr,
    output reg  [(DATA_WIDTH-1):0] data_out,
    output reg                     we
);

// Movement tick generator.
// COUNT controls how often the llama moves.
// STATE_ITER must stay high long enough for the FSM to complete:
// FETCH_X -> SAVE_X -> FETCH_Y -> SAVE_Y -> FETCH_M -> SAVE_M.
localparam COUNT      = 32'd1250000;
localparam STATE_ITER = 32'd16;
wire timer;

pulse pwm (
    .clk(clk),
    .rst(rst),
    .length1(STATE_ITER),
    .length2(COUNT),
    .pulse(timer)
);

localparam FETCH_X = 3'd0;
localparam SAVE_X  = 3'd1;
localparam FETCH_Y = 3'd2;
localparam SAVE_Y  = 3'd3;
localparam FETCH_M = 3'd4;
localparam SAVE_M  = 3'd5;

reg [2:0] PS, NS;

// Screen and sprite bounds for the llama glyphs.
// The uploaded llama sprite sources define 48x48 frames and 6 animation frames. 
localparam SCREEN_WIDTH  = 16'd640;
localparam SCREEN_HEIGHT = 16'd480;
localparam GLYPH_WIDTH   = 16'd48;
localparam GLYPH_HEIGHT  = 16'd48;
localparam X_MIN         = 16'd0;
localparam Y_MIN         = 16'd0;
localparam X_MAX         = SCREEN_WIDTH  - GLYPH_WIDTH;   // 592
localparam Y_MAX         = SCREEN_HEIGHT - GLYPH_HEIGHT;  // 432

// Zig-zag step size.
localparam X_STEP        = 16'd4;
localparam Y_STEP        = 16'd4;

// Use all 6 frames from glyphs.hex: frame indices 0..5.
// Because SAVE_M happens after SAVE_X and SAVE_Y, the frame changes exactly
// when the sprite changes position.
localparam LAST_FRAME    = 16'd5;

// Direction bits: 1 = positive direction, 0 = negative direction.
reg x_dir_in, x_dir_out;
reg y_dir_in, y_dir_out;

always @(posedge clk or negedge rst) begin
    if (~rst) begin
        x_dir_out <= 1'b1;
        y_dir_out <= 1'b1;
    end
    else begin
        x_dir_out <= x_dir_in;
        y_dir_out <= y_dir_in;
    end
end

always @(posedge clk or negedge rst) begin
    if (~rst)
        PS <= FETCH_X;
    else if (timer)
        PS <= NS;
end

always @* begin
    addr     = {ADDR_WIDTH{1'b0}};
    data_out = {DATA_WIDTH{1'b0}};
    we       = 1'b0;
    NS       = PS;
    x_dir_in = x_dir_out;
    y_dir_in = y_dir_out;

    case (PS)
        FETCH_X: begin
            addr = 16'h1000;
            NS   = SAVE_X;
        end

        SAVE_X: begin
            addr = 16'h1000;
            we   = 1'b1;

            if (x_dir_out) begin
                if (data_in >= (X_MAX - X_STEP)) begin
                    data_out = X_MAX;
                    x_dir_in = 1'b0;
                end
                else begin
                    data_out = data_in + X_STEP;
                end
            end
            else begin
                if (data_in <= (X_MIN + X_STEP)) begin
                    data_out = X_MIN;
                    x_dir_in = 1'b1;
                end
                else begin
                    data_out = data_in - X_STEP;
                end
            end

            NS = FETCH_Y;
        end

        FETCH_Y: begin
            addr = 16'h1001;
            NS   = SAVE_Y;
        end

        SAVE_Y: begin
            addr = 16'h1001;
            we   = 1'b1;

            if (y_dir_out) begin
                if (data_in >= (Y_MAX - Y_STEP)) begin
                    data_out = Y_MAX;
                    y_dir_in = 1'b0;
                end
                else begin
                    data_out = data_in + Y_STEP;
                end
            end
            else begin
                if (data_in <= (Y_MIN + Y_STEP)) begin
                    data_out = Y_MIN;
                    y_dir_in = 1'b1;
                end
                else begin
                    data_out = data_in - Y_STEP;
                end
            end

            NS = FETCH_M;
        end

        FETCH_M: begin
            addr = 16'h1002;
            NS   = SAVE_M;
        end

        SAVE_M: begin
            addr = 16'h1002;
            we   = 1'b1;

            if (data_in >= LAST_FRAME)
                data_out = {DATA_WIDTH{1'b0}};
            else
                data_out = data_in + 16'd1;

            NS = FETCH_X;
        end

        default: begin
            NS = FETCH_X;
        end
    endcase
end

endmodule
