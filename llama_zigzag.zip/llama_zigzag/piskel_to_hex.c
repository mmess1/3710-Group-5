/**
  * Converts exported llama Piskel C-array data into glyphs.hex for the VGA ROM.
  *
  * The uploaded llama sprites use 6 frames of 48x48 pixels. This converter
  * directly aliases the original LLAMA_* names, so you do not need to rename
  * the array or macros inside the header.
  */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "llama.h"

#define data         llama_data
#define FRAME_COUNT  LLAMA_FRAME_COUNT
#define FRAME_WIDTH  LLAMA_FRAME_WIDTH
#define FRAME_HEIGHT LLAMA_FRAME_HEIGHT

#define FILENAME "glyphs.hex"

static uint8_t get_red(uint32_t pixel)
{
    return (uint8_t)(pixel >> 0);
}

static uint8_t get_green(uint32_t pixel)
{
    return (uint8_t)(pixel >> 8);
}

static uint8_t get_blue(uint32_t pixel)
{
    return (uint8_t)(pixel >> 16);
}

int main(void)
{
    FILE *fptr;
    time_t now;
    int i, j;
    uint8_t r, g, b;

    time(&now);

    fptr = fopen(FILENAME, "w");
    if (fptr == NULL) {
        printf("\r\nERROR opening %s\r\n\r\n", FILENAME);
        exit(1);
    }

    printf("\r\nIterating llama sprites...");

    fprintf(fptr, "// Outputted data from piskel_to_hex.c\r\n");
    fprintf(fptr, "// Glyph width: %u\r\n", FRAME_WIDTH);
    fprintf(fptr, "// Glyph height: %u\r\n", FRAME_HEIGHT);
    fprintf(fptr, "// Frame count: %u\r\n", FRAME_COUNT);

    for (i = 0; i < FRAME_COUNT; i++) {
        fprintf(fptr, "\n\n// glyph[%u] -- added %s\r\n\n", i, ctime(&now));
        for (j = 0; j < (FRAME_WIDTH * FRAME_HEIGHT); j++) {
            r = get_red(data[i][j]);
            g = get_green(data[i][j]);
            b = get_blue(data[i][j]);
            fprintf(fptr, "%02x%02x%02x\r\n", r, g, b);
        }
    }

    printf("Done!\r\n\r\n");
    fclose(fptr);
    return 0;
}
