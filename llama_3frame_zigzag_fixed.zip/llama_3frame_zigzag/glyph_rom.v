module glyph_rom
#(
    parameter DATA_WIDTH = 24,
    parameter ADDR_WIDTH = 14,
    parameter GLYPH_FILE = "glyphs.hex"
)
(
    input  wire                    clk,
    input  wire [(ADDR_WIDTH-1):0] addr,
    output reg  [(DATA_WIDTH-1):0] q
);

reg [(DATA_WIDTH-1):0] rom [0:((2**ADDR_WIDTH)-1)];

initial begin
    $readmemh(GLYPH_FILE, rom);
end

always @(posedge clk) begin
    q <= rom[addr];
end

endmodule
