module vga_controller
(
    input  wire       vga_clk,
    input  wire       rst,
    output reg        vga_hs,
    output reg        vga_vs,
    output reg        vga_blank_n,
    output reg [9:0]  hcount,
    output reg [9:0]  vcount
);

localparam H_VISIBLE = 10'd640;
localparam H_FRONT   = 10'd16;
localparam H_SYNC    = 10'd96;
localparam H_BACK    = 10'd48;
localparam H_TOTAL   = H_VISIBLE + H_FRONT + H_SYNC + H_BACK;

localparam V_VISIBLE = 10'd480;
localparam V_FRONT   = 10'd10;
localparam V_SYNC    = 10'd2;
localparam V_BACK    = 10'd33;
localparam V_TOTAL   = V_VISIBLE + V_FRONT + V_SYNC + V_BACK;

reg [9:0] h_ctr;
reg [9:0] v_ctr;
wire visible;

assign visible = (h_ctr < H_VISIBLE) && (v_ctr < V_VISIBLE);

always @(posedge vga_clk or negedge rst) begin
    if (~rst) begin
        h_ctr       <= 10'd0;
        v_ctr       <= 10'd0;
        hcount      <= 10'd0;
        vcount      <= 10'd0;
        vga_hs      <= 1'b1;
        vga_vs      <= 1'b1;
        vga_blank_n <= 1'b0;
    end
    else begin
        if (h_ctr == (H_TOTAL - 1'b1)) begin
            h_ctr <= 10'd0;
            if (v_ctr == (V_TOTAL - 1'b1))
                v_ctr <= 10'd0;
            else
                v_ctr <= v_ctr + 10'd1;
        end
        else begin
            h_ctr <= h_ctr + 10'd1;
        end

        vga_hs <= ~((h_ctr >= (H_VISIBLE + H_FRONT)) &&
                    (h_ctr <  (H_VISIBLE + H_FRONT + H_SYNC)));

        vga_vs <= ~((v_ctr >= (V_VISIBLE + V_FRONT)) &&
                    (v_ctr <  (V_VISIBLE + V_FRONT + V_SYNC)));

        vga_blank_n <= visible;

        if (visible) begin
            hcount <= h_ctr;
            vcount <= v_ctr;
        end
        else begin
            hcount <= 10'd0;
            vcount <= 10'd0;
        end
    end
end

endmodule
